﻿Imports System
Imports System.Data
Imports System.Data.OleDb
Partial Public Class _Default
    Inherits System.Web.UI.Page
    Private strSQL As String
    Private objDataTable As DataTable
    Private objReader As OleDbDataReader
    Private objAdapter As OleDbDataAdapter
    Private objDataset As DataSet
    Private myCon As OleDbConnection
    Private objCommand As OleDbCommand
    Private strCon As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            strCon = "Provider=Microsoft.Jet.OLEDB.4.0; Data Source=C:\ASP-siti\soalUAS\soalUAS\database.mdb;"
            If Not IsPostBack Then
                Call ListGrid()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub ListGrid()
        Try
            myCon = New OleDbConnection(strCon)
            myCon.Open()
            strSQL = "SELECT * FROM tbKaryawan ORDER BY nik ASC"
            objAdapter = New OleDbDataAdapter(strSQL, myCon)
            objDataset = New DataSet
            objAdapter.Fill(objDataset)
            grdList.DataSource = objDataset
            grdList.DataBind()
            myCon.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Try
            myCon = New OleDbConnection(strCon)
            myCon.Open()
            strSQL = "INSERT INTO tbKaryawan (nik,nm_karyawan,bagian,jabatan,status,gaji_pokok,tujangan,pajak,gaji_bersih) VALUES ('" & txtNIK.Text & "','" & txtNamaKaryawan.Text & "','" & txtBagian.Text & "','" & txtJabatan.Text & "','" & txtStatus.Text & "','" & txtGajiPokok.Text & "','" & txtTunjangan.Text & "','" & txtPajak.Text & "'," & CDbl(txtGajiBersih.Text) & ")"

            objCommand = New OleDbCommand(strSQL, myCon)
            If objCommand.ExecuteNonQuery Then
                MsgBox("DATA SUDAH DISIMPAN")
            Else
                MsgBox("DATA TIDAK DAPAT DISIMPAN")
            End If
            myCon.Close()
            Call ListGrid()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub grdList_SelectedIndexChanged(ByVal sender As Object, ByVale As System.EventArgs) Handles grdList.SelectedIndexChanged
        Try
            txtNIK.Text = grdList.SelectedRow.Cells(1).Text
            txtNamaKaryawan.Text = grdList.SelectedRow.Cells(2).Text
            txtBagian.Text = grdList.SelectedRow.Cells(3).Text
            txtJabatan.Text = grdList.SelectedRow.Cells(4).Text
            txtStatus.Text = grdList.SelectedRow.Cells(5).Text
            txtGajiPokok.Text = grdList.SelectedRow.Cells(6).Text
            txtTunjangan.Text = grdList.SelectedRow.Cells(7).Text
            txtPajak.Text = grdList.SelectedRow.Cells(8).Text
            txtGajiBersih.Text = Format(CDbl(grdList.SelectedRow.Cells(9).Text), "#,##0.00")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

End Class