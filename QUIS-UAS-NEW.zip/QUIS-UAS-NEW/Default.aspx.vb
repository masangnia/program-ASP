﻿Imports System
Imports System.Data
Imports System.Data.OleDb

Partial Public Class _Default
    Inherits System.Web.UI.Page
    Private strCon As String
    Private myCon As OleDbConnection
    Private strSQL As String
    Private objCommand As OleDbCommand
    Private objAdapter As OleDbDataAdapter
    Private objDataset As DataSet

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            strCon = "Provider=Microsoft.Jet.OLEDB.4.0; Data Source=C:\ASP-siti\QUIS-UAS-NEW\data.mdb"
            If Not IsPostBack Then
                Call ListGrid()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Try
            myCon = New OleDbConnection(strCon)
            myCon.Open()
            strSQL = "INSERT INTO TBL_BARANG (NIK,NM_KARYAWAN,BAGIAN,JABATAN,STATUS,GAJI_POKOK,TUNJANGAN,PAJAK,GAJI_BERSIH) VALUES ('" & txtNIK.Text & "','" & txtNamaKaryawan.Text & "','" & txtBagian.Text & "','" & txtJabatan.Text & "','" & txtStatus.Text & "','" & txtGaji.Text & "','" & txtTunjangan.Text & "','" & txtPajak.Text & "'," & CDbl(txtGajiBersih.Text) & ") "
            objCommand = New OleDbCommand(strSQL, myCon)


            If objCommand.ExecuteNonQuery Then
                MsgBox("DATA SUDAH DISIMPAN")
            Else
                MsgBox("DATA TIDAK DAPAT DISIMPAN")
            End If
            myCon.Close()
            Call ListGrid()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub ListGrid()
        Try
            myCon = New OleDbConnection(strCon)
            myCon.Open()
            strSQL = "SELECT * FROM TBL_BARANG ORDER BY NIK ASC"
            objAdapter = New OleDbDataAdapter(strSQL, myCon)
            objDataset = New DataSet
            objAdapter.Fill(objDataset)
            grdList.DataSource = objDataset
            grdList.DataBind()
            myCon.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub grdList_SelectedIndexChanged(ByVal sender As Object, ByVale As System.EventArgs) Handles grdList.SelectedIndexChanged
        Try
            txtNIK.Text = grdList.SelectedRow.Cells(1).Text
            txtNamaKaryawan.Text = grdList.SelectedRow.Cells(2).Text
            txtBagian.Text = grdList.SelectedRow.Cells(3).Text
            txtJabatan.Text = grdList.SelectedRow.Cells(4).Text
            txtStatus.Text = grdList.SelectedRow.Cells(5).Text
            txtGaji.Text = grdList.SelectedRow.Cells(6).Text
            txtTunjangan.Text = grdList.SelectedRow.Cells(7).Text
            txtPajak.Text = grdList.SelectedRow.Cells(8).Text
            txtGajiBersih.Text = Format(CDbl(grdList.SelectedRow.Cells(9).Text), "#,##0.00")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub


    Private Sub btnUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        Try
            myCon = New OleDbConnection(strCon)
            myCon.Open()
            strSQL = "UPDATE TBL_BARANG SET NM_KARYAWAN='" & txtNamaKaryawan.Text & "',BAGIAN='" & txtBagian.Text & "',JABATAN='" & txtJabatan.Text & "',STATUS='" & txtStatus.Text & "',GAJI_POKOK='" & txtGaji.Text & "',TUNJANGAN='" & txtTunjangan.Text & "',PAJAK='" & txtPajak.Text & "'GAJI_BERSIH=" & CDbl(txtGajiBersih.Text) & " WHERE NIK='" & txtNIK.Text & "' "
            objCommand = New OleDbCommand(strSQL, myCon)
            If objCommand.ExecuteNonQuery Then
                MsgBox("DATA SUDAH DIUPDATE")
            Else
                MsgBox("DATA TIDAK DAPAT DIUPDATE")
            End If
            myCon.Close()
            Call ListGrid()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Try
            'Untuk Pesan Delete bisa menggunakan JavaScript jika akan di running dalam Web Server
            If MsgBox("Yakin akan dihapus ?", MsgBoxStyle.Information + MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                myCon = New OleDbConnection(strCon)
                myCon.Open()
                strSQL = "DELETE FROM TBL_BARANG WHERE NIK='" & txtNIK.Text & "' "
                objCommand = New OleDbCommand(strSQL, myCon)
                If objCommand.ExecuteNonQuery Then
                    MsgBox("DATA SUDAH DI DELETE")
                Else
                    MsgBox("DATA TIDAK DAPAT DI DELETE")
                End If
                myCon.Close()
                Call ListGrid()
            Else
                MsgBox("Data Batal DIhapus")
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub
End Class